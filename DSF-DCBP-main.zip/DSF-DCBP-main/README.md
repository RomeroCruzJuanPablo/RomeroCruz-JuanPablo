# Data Science Fundamentals for Chemists and Biochemists

Material for the course Data Science Fundamentals for Chemists and Biochemists at the University of Bern. 

Second edition spring term 2023, S. Haug
